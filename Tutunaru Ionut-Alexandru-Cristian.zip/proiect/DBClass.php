<?php 

class DBClass
{
    protected $conn;

    public function Db(){
        $this->conn = new mysqli("localhost", "myuser", "123", "finalproject");
        if($this->conn->connect_error){
            die('Connection error!')
        }
       return $this->conn;
    }
}