<?php

define('APP_PATH', 'myApp/');
define('MODELS', 'models/');
define('VIEWS', 'views/');
define('CONTROLLERS', 'controllers/');



spl_autoload_register(function($className){

$relPath = '';

$class = strtolower($className); //litere mici

if(substr_count($class, 'controller')) $relPath = CONTROLLERS;
if(substr_count($class, 'model')) $relPath = MODELS;
if(substr_count($class, 'view')) $relPath = VIEWS; // linie teoretic inutila

if($relPath == '') die ('Invalid Path!');

$filePath = APP_PATH . $relPath . $className . '.php';


if(file_exists($filePath)){
    require_once $filePath;

}
else{
    die("File Not found! - $filePath");
}
});