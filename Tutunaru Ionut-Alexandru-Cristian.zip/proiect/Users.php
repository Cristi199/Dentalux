
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
</head>
<body>
    


<?php

 require_once 'DBClass.php';

class Users extends DBClass
{
    protected $name;
    protected $email;
    protected $password;
    
    public function __construct($uName='implicit', $uEmail='implicit', $uPass='implicit'){
        $this->name = $uName;
        $this->email = $uEmail;
        $this->password = $uPass;
    }

    public function showUsers(){
        $q = "SELECT * FROM appointment";
        $result = $this->Db()->query($q);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function delUsers($id){
        $q = "DELETE FROM appointment WHERE `ID` = $id";
        $result = $this->Db()->query($q);
        if($result) return true;
        else return false;
    }

    public function tabel($someArray){
        if(is_array($someArray)){
            echo '<table class="table table-striped"><tr>';
            foreach(array_keys($someArray[0]) as $key){
                echo '<th>'.$key.'</th>';
            }
            echo '</tr>';

            foreach($someArray as $user){
                $id = $user['ID'];
                echo '<tr>';
                foreach($user as $value){
                    echo '<td>'.$value.'</td>';
                }
                echo "<td><a class='btn btn-danger' href='Delete.php?ID=$id'>DELETE</a></td>";
                echo '</tr>';
            }
            echo '</table>';
        }
    }

}
?>

</body>
</html>