<?php

include_once 'config.php';

$user1 = new Users;

$id = $_GET['ID'];
$user1->delUsers($id);

header('Location: ceva.php');